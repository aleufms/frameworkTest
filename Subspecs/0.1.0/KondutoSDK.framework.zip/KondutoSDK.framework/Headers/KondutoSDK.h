//
//  KondutoSDK.h
//  KondutoSDK
//
//  Created by Alessandro Nakamuta on 7/26/16.
//
//

#import <UIKit/UIKit.h>

//! Project version number for KondutoSDK.
FOUNDATION_EXPORT double KondutoSDKVersionNumber;

//! Project version string for KondutoSDK.
FOUNDATION_EXPORT const unsigned char KondutoSDKVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <KondutoSDK/PublicHeader.h>


